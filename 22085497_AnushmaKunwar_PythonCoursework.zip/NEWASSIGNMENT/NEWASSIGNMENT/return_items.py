import os
import datetime
def return_items(equipment_dict, invoice_path):

    returned_items = []

    rented_items = []

    return_date_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    rent_days=0

    customer_name=None

    fine=0

    fined_days=0

    try:

        with open(invoice_path, 'r') as file:

          lines = file.readlines()

        customer_name = lines[0].split(": ")[1].strip()

        rent_date = lines[-3].split(": ")[1].strip()

        

        # Calculate the number of days rented

        rent_days = (datetime.datetime.now() - datetime.datetime.strptime(rent_date,"%Y-%m-%d %H:%M:%S")).days

        if rent_days > 5:

            fine = (rent_days - 5) * 10  # Assuming a $10 fine per day

        else:

            fine = 0

        fined_days=rent_days - 5

        # Extract rented items information

        rented_items_info = [lines[i:i+4] for i in range(1, len(lines)-3, 5)]  

        

        print(f"\nRented Items for {customer_name}:")

        i=1

        for idx, item_info in enumerate(rented_items_info, start=1):

            if(int(item_info[1].split(": ")[1])>0):

                equipment_info = item_info[0].split(" (")

                equipment_name = equipment_info[0].split(": ")[1]

                brand = equipment_info[1][:-1]

                quantity = int(item_info[1].split(": ")[1])

                price = float(item_info[2].split(": $")[1])

                total_cost = float(item_info[3].split(": $")[1])

                rented_items.append([equipment_name, brand, price, quantity, total_cost, rent_date,quantity])

                print(f"{i}. Equipment: {equipment_name} ({brand}, Quantity: {quantity}, Total Cost: ${total_cost}, Rent Date: {rent_date}")

                i+=1

        

        

       # Prompt user to select items and quantity to return

        items_to_return = []

        if(len(rented_items)>0):

            proceed=True

            while proceed:

                choices = input("\nEnter the numbers of the items to return (comma-separated, or 'q' to quit): ").split(',')

                if 'q' in choices:

                    break

                

                for choice in choices:#list

                    try:

                        choice = int(choice)

                        if 1 <= choice <= len(rented_items):

                            quantity_to_return = int(input(f"Enter the quantity of item {rented_items[choice-1][0]} to return: "))

                            if 1 <= quantity_to_return <= rented_items[choice-1][3]:

                                items_to_return.append((rented_items[choice - 1], quantity_to_return))

                                rented_items[choice-1][6]=rented_items[choice-1][3]-quantity_to_return

                                proceed=False

                            else:

                                print(f"Invalid quantity. Please enter a value between 1 and {rented_items[choice-1][3]}.")

                                proceed=True

                        else:

                            print(f"Invalid choice: {choice}")

                            proceed=True

                    except ValueError:

                        print(f"Invalid input: {choice}")

                        break

        else:

            print(f"There aren't any items for {customer_name} to return")

                    

        for (equipment, brand, price, quantity, total_cost, rent_date,remaining), quantity_to_return in items_to_return:

            # Update equipment quantities

            if equipment in equipment_dict:

                equipment_dict[equipment]['quantity'] += quantity_to_return

            else:

                equipment_dict[equipment] = {'brand': brand, 'price': price, 'quantity': quantity_to_return}

            

            returned_items.append((equipment, brand, price, quantity_to_return, price*quantity_to_return, return_date_time, rent_date))

        if(len(rented_items)>0):

            with open(invoice_path, 'w') as file:

                tst_total_cost=0

                file.write(f"Customer: {customer_name}\n")

                for equipment, brand, price, quantity, total_cost, rent_date,remaining in rented_items:

                    file.write(f"Equipment: {equipment} ({brand}\n")

                    file.write(f"Quantity: {remaining}\n")

                    file.write(f"Price per item: ${price}\n")

                    file.write(f"Cost: ${price*remaining}\n")

                    file.write('-' * 20 + '\n') 

                    tst_total_cost+=price*remaining

                file.write(f"Rent Date: {rent_date}\n")

                file.write(f"Total Cost: ${tst_total_cost}\n")

                file.write(f"Rental Duration: 5 Days")
    except FileNotFoundError:
        print(f"Invoice path not found")

    return returned_items, customer_name,fine,fined_days





# Modify the main function accordingly to allow returning items


import datetime


def generate_return_invoice(customer_name, returned_items,fine,fined_days, transaction_dir):#file generating of returning equipments

    timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")

    invoice_name = f"{customer_name}_return_{timestamp}.txt"

    invoice_path = os.path.join(transaction_dir, invoice_name)



    total_refund = 0



    with open(invoice_path, 'w') as file:#writing in a file

        file.write(f"Customer: {customer_name}\n")

        for equipment, brand, price, quantity, total_cost, return_datetime, rent_date in returned_items:

            file.write(f"Equipment: {equipment} ({brand}\n")

            file.write(f"Quantity Returned: {quantity}\n")

            file.write(f"Price per item: ${price}\n")

            file.write(f"Total Cost: ${total_cost}\n")

            file.write(f"Rent Date: {rent_date}\n")

            file.write(f"Return Date and Time: {return_datetime}\n")

            refund_amount = total_cost

            total_refund += refund_amount

            file.write(f"Refund Amount: ${refund_amount}\n")

            file.write('-' * 20 + '\n')

        file.write(f"Total Refund: ${total_refund}\n")

        if fine > 0:

            file.write(f"Fine (for {fined_days} extra days): ${fine}\n")

        



    return invoice_path
