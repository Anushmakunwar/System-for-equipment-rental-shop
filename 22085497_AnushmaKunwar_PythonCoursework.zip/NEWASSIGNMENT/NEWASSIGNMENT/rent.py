import os
import datetime #import datetime module  for timestamp generation

def rent_equipment(equipment_dict, choices):
    '''rent selected equipment  items and update their quantities  in the equipment dictionary.
    equipment_dict(dict):A dictionary containing equipment information.
    choices(list):A list of tuples,where each tuples contains the index of the the chosen equipmet and quantity to rent.
    '''

    rented_items = []#initialize an empty list to store rented items

    rent_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")#for getting current date and time

    for choice, quantity in choices:

        equipment_name = list(equipment_dict.keys())[choice - 1]

        details = equipment_dict[equipment_name]

        if details['quantity'] >= quantity:#checking if the enough items are avialbe to rent

            details['quantity'] -= quantity#Append the rented items to the list

            rented_items.append((equipment_name, details['brand'], details['price'], quantity, rent_date))

        else:

            print(f"Not enough {equipment_name} available.")

            return None

    return rented_items



def generate_invoice(customer_name, rented_items, transaction_dir):

    timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")

    invoice_name = f"{customer_name}_{timestamp}.txt"

    invoice_path = os.path.join(transaction_dir, invoice_name)



    total_cost = 0



    with open(invoice_path, 'w') as file:#opening of file in writing mode

        file.write(f"Customer: {customer_name}\n")

        for equipment, brand, price, quantity,rent_date in rented_items:

            file.write(f"Equipment: {equipment} ({brand})\n")

            file.write(f"Quantity: {quantity}\n")

            file.write(f"Price per item: ${price}\n")

            file.write(f"Cost: ${price*quantity}\n")

            total_cost += price * quantity

            file.write('-' * 20 + '\n')

        file.write(f"Rent Date: {rent_date}\n")

        file.write(f"Total Cost: ${total_cost}\n")

        file.write(f"Rental Duration: 5 Days")



        



    return invoice_path
