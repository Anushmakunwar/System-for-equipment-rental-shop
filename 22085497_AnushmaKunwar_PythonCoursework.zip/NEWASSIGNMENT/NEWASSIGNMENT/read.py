import os

def read_equipment_file(file_name):#function for readfile

    equipment_dict = {}

    try:#using try and except for exception handling

        with open(file_name, 'r') as file:

            for line in file:

                name, brand, price, quantity = line.strip().split(', ')

                equipment_dict[name] = {'brand': brand, 'price': float(price), 'quantity': int(quantity)}

        return equipment_dict

    except FileNotFoundError:

        print(f"The file '{file_name}' does not exist.")

        return {}





def update_equipment_file(equipment_file,equipment_dict):#updating equipment file

    with open(equipment_file, 'w') as file:

        for equipment, details in equipment_dict.items():

            file.write(f"{equipment}, {details['brand']}, {details['price']}, {details['quantity']}\n")



def display_available_equipment(equipment_dict):#Display available equipments

    print("Available Equipment:")

    for idx, (equipment, details) in enumerate(equipment_dict.items(), start=1):

        print(f"{idx}. {equipment} ({details['brand']}) - Price: ${details['price']} - Quantity: {details['quantity']}")

