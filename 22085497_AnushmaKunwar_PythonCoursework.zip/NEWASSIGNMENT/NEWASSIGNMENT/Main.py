import os
from datetime import datetime
from read import read_equipment_file,display_available_equipment
from rent import rent_equipment,generate_invoice
from return_items import return_items,generate_return_invoice


def input_text():#Display welcome message
    welcome_message = """
==============================================================
        Welcome! To Equipment Rental Shop
=============================================================="""
    print(welcome_message)

def update_equipment_file(equipment_file,equipment_dict):

    with open(equipment_file, 'w') as file:

        for equipment, details in equipment_dict.items():

            file.write(f"{equipment}, {details['brand']}, {details['price']}, {details['quantity']}\n")




def main():

    equipment_file = "equipment.txt"#Define the equipment file and transaction directory

    transaction_dir = "transactions"



    if not os.path.exists(transaction_dir):#Check if the transaction directory exists,

        os.makedirs(transaction_dir)



    equipment_dict = read_equipment_file(equipment_file)#Read the equipment information from the equipment file



    if equipment_dict:
        
        input_text()#Display the elcome message

        while True:

            print("\n1. Rent Equipment")#Display the main menu

            print("2. Return Equipment")

            print("3. Exit")

            choice = input("Enter your choice (1/2/3): ")#Gets user choice 

            

            if choice == '1':#Rent equipment 

                display_available_equipment(equipment_dict)

                while True:
                 customer_name = input("\nEnter customer name : ")

                 if customer_name.lower() == 'q':
                    break

                 if customer_name.isdigit():
                    print("Please enter a string, not an integer.")
                 else:
                    print(f"Customer name: {customer_name}")

                    break


                choices = []

                while True:
                    try:

                      equipment_choice = int(input("Enter the number of the equipment to rent (or '0' to finish): "))

                      if equipment_choice == 0:

                         break
                    
                       
                    

                      if 1 <= equipment_choice <= len(equipment_dict):

                        quantity = int(input(f"Enter the quantity of {list(equipment_dict.keys())[equipment_choice - 1]} to rent: "))
                        if quantity > 0:

                         choices.append((equipment_choice, quantity))
                        else:
                         print("Quantity must be greater than 0")

                      else:

                        print("Invalid equipment choice. Please try again.")
                    except ValueError:
                      print("Invalid integer.Please enter a valid integer")
                
                    



                rented_items = rent_equipment(equipment_dict, choices)#Rented the selected items

                if rented_items:#Generate an invoice

                    invoice_path = generate_invoice(customer_name, rented_items, transaction_dir)

                    print(f"Invoice generated for {customer_name}.")

                    print(f"Invoice saved at: {invoice_path}")

                    update_equipment_file(equipment_file,equipment_dict)



                    

            elif choice == '2':#Return equipment

                invoice_name = input("Enter the name of the invoice to return items from: ")

                invoice_path = os.path.join(transaction_dir, invoice_name)

                if os.path.exists(invoice_path):

                    returned_items, customer_name,fine,fined_days = return_items(equipment_dict, invoice_path)

                    if(len(returned_items)>0):

                        return_invoice_path = generate_return_invoice(customer_name, returned_items,fine,fined_days, transaction_dir)

                        print(f"Returned items invoice generated for {customer_name}.")

                        print(f"Invoice saved at: {return_invoice_path}")

                        update_equipment_file(equipment_file,equipment_dict)

                else:

                    print(f"Invoice '{invoice_name}' not found.")

                    

            elif choice == '3':#Exit the program
                print("Equipment information updated.Goodbye!")

            else:
                print("Invalid choice. Please enter a number from the given choices 1,2 or 3.")

                break



    print(equipment_dict.items())  #For debugging process         

    



if __name__ == "__main__":

    main()

